// MSSQL
const { Sequelize, DataTypes } = require("sequelize");
const dbInfo = {
  database: 'TEST_HFC',
  account: 'SA',
  pwd: 'nks^=Dr^38w^i38',
  // host: '127.0.0.1',
  host: 'LAPTOP-SC',
  port: 1433,
  encrypt: true
}
const MSSQL = new Sequelize(dbInfo.database, dbInfo.account, dbInfo.pwd, {
  host: dbInfo.host,
  port: dbInfo.port,
  dialect: "mssql",
  dialectOptions: {
    options: {
      encrypt: dbInfo.encrypt,
    },
  },
});

module.exports = { MSSQL, Sequelize, DataTypes };
