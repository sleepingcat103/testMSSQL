// const ANSWERPACK = require('./ANSWERPACK')
// const TRACE = require('./trace')
const REQRES_LOGS = require('./reqResLogs')

REQRES_LOGS.insertLog({
  TIME: '123',
  FROM_IP: '123',
  METHOD: '123',
  ORIGINAL_URI: '123',
  URI: '123',
  USER: '123',
  REQUEST_DATA: '123',
  STATUS_CODE: 111,
  RESPONSE_DATA: '123',
  REFERER: '123',
  USER_AGENT: '123',
  START_TIME: 111,
  END_TIME: 111
})

module.exports = {
  REQRES_LOGS
}